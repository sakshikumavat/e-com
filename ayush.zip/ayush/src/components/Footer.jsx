import { Link } from 'react-router-dom'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-gray-300 bg-gray-50 mt-16">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
         
          <div>
            <h3 className="font-bold text-lg mb-4 text-gray-800">StyleHub</h3>
            <p className="text-gray-600 text-sm">
              Quality fashion for everyone. Shop our curated collection of timeless pieces.
            </p>
          </div>

          
          <div>
            <h4 className="font-semibold mb-4 text-gray-800">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-600 hover:text-gray-900 text-sm">Home</Link></li>
              <li><Link to="/products" className="text-gray-600 hover:text-gray-900 text-sm">Shop</Link></li>
              <li><Link to="/about" className="text-gray-600 hover:text-gray-900 text-sm">About</Link></li>
              <li><Link to="/contact" className="text-gray-600 hover:text-gray-900 text-sm">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-gray-800">Customer Service</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Shipping Info</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Returns</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">FAQ</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Privacy Policy</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-semibold mb-4 text-gray-800">Newsletter</h4>
            <p className="text-gray-600 text-sm mb-3">Subscribe to get special offers and updates.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="flex-1 px-3 py-2 border border-gray-300 rounded-l text-sm"
              />
              <button className="bg-gray-800 text-white px-4 py-2 rounded-r text-sm hover:bg-gray-700">
                Subscribe
              </button>
            </div>
          </div>
        </div>

       
        
      </div>
    </footer>
  )
}
