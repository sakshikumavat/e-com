import { Link } from 'react-router-dom'
import { useState } from 'react'
import products from '../data/products'

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState('All')

  const allProducts = products

  const categories = ['All', 'Tops', 'Bottoms', 'Outerwear', 'Shoes']

  const filteredProducts = selectedCategory === 'All' 
    ? allProducts 
    : allProducts.filter(p => p.category === selectedCategory)

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Shop Our Collection</h1>

      
      <div className="mb-12">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filter by Category</h3>
        <div className="flex flex-wrap gap-3">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-gray-800 text-white'
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <Link key={product.id} to={`/products/${product.id}`}>
            <div className="border border-gray-300 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-40 w-full bg-gray-200 overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
              </div>
              <div className="p-4">
                <p className="text-xs text-gray-500 uppercase mb-1">{product.category}</p>
                <h3 className="text-base font-semibold text-gray-900 mb-2">{product.name}</h3>
                <p className="text-lg font-bold text-gray-900">{product.priceLabel}</p>
                <button className="mt-3 w-full bg-gray-800 text-white py-2 rounded hover:bg-gray-700 text-sm font-medium">
                  View Details
                </button>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-lg text-gray-600">No products found in this category</p>
        </div>
      )}
    </div>
  )
}
