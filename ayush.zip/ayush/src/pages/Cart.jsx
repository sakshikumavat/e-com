import { Link } from 'react-router-dom'
import { useState } from 'react'
import products from '../data/products'

export default function Cart() {
  const [cartItems] = useState([
    { id: 1, ...products.find((p) => p.id === 1), quantity: 2 },
    { id: 2, ...products.find((p) => p.id === 2), quantity: 1 },
  ])

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  const tax = subtotal * 0.1
  const shipping = subtotal > 50 ? 0 : 10
  const total = subtotal + tax + shipping

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

      {cartItems.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="border border-gray-300 rounded-lg overflow-hidden">
              <div className="hidden md:grid grid-cols-4 gap-4 bg-gray-50 p-4 font-semibold text-gray-900 border-b border-gray-300">
                <div>Product</div>
                <div className="text-center">Price</div>
                <div className="text-center">Quantity</div>
                <div className="text-right">Total</div>
              </div>

              {cartItems.map((item) => (
                <div key={item.id} className="p-4 border-b border-gray-300 last:border-b-0">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 bg-gray-200 rounded overflow-hidden">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{item.name}</p>
                        <p className="text-sm text-gray-600 md:hidden">Price: ${item.price.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="text-center hidden md:block">
                      ${item.price.toFixed(2)}
                    </div>
                    <div className="flex items-center justify-center gap-3 md:justify-center">
                      <button className="border border-gray-300 px-2 py-1 rounded hover:bg-gray-100">−</button>
                      <span className="font-semibold">{item.quantity}</span>
                      <button className="border border-gray-300 px-2 py-1 rounded hover:bg-gray-100">+</button>
                    </div>
                    <div className="text-right">
                      ${(item.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                  <button className="text-red-600 hover:text-red-700 text-sm mt-2 md:mt-0">Remove</button>
                </div>
              ))}
            </div>

            <Link
              to="/products"
              className="inline-block mt-6 text-gray-600 hover:text-gray-900 font-medium"
            >
              ← Continue Shopping
            </Link>
          </div>

          {/* Order Summary */}
          <div className="bg-gray-50 rounded-lg p-6 h-fit border border-gray-300">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Summary</h2>

            <div className="space-y-4 mb-6 border-b border-gray-300 pb-6">
              <div className="flex justify-between">
                <span className="text-gray-700">Subtotal</span>
                <span className="font-semibold text-gray-900">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Tax</span>
                <span className="font-semibold text-gray-900">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Shipping</span>
                <span className="font-semibold text-gray-900">
                  {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                </span>
              </div>
              {shipping === 0 && (
                <p className="text-sm text-green-600">Free shipping on orders over $50!</p>
              )}
            </div>

            <div className="flex justify-between mb-6 text-lg">
              <span className="font-bold text-gray-900">Total</span>
              <span className="font-bold text-gray-900">${total.toFixed(2)}</span>
            </div>

            <button className="w-full bg-gray-800 text-white py-3 rounded-lg hover:bg-gray-700 font-bold mb-3">
              Proceed to Checkout
            </button>
            <button className="w-full border-2 border-gray-800 text-gray-800 py-3 rounded-lg hover:bg-gray-50 font-bold">
              Continue Shopping
            </button>

            <div className="mt-6 pt-6 border-t border-gray-300">
              <h3 className="font-semibold text-gray-900 mb-3">We Accept</h3>
              <p className="text-sm text-gray-600">Credit Cards, PayPal, and Apple Pay</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-xl text-gray-600 mb-6">Your cart is empty</p>
          <Link
            to="/products"
            className="inline-block bg-gray-800 text-white px-8 py-3 rounded-lg hover:bg-gray-700 font-medium"
          >
            Start Shopping
          </Link>
        </div>
      )}
    </div>
  )
}
