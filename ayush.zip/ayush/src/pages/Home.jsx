import { Link } from 'react-router-dom'
import products from '../data/products'

export default function Home() {
  const featuredProducts = products.slice(0, 3)

  return (
    <div className="max-w-6xl mx-auto px-4">
      
      <section className="py-20 text-center">
        <h1 className="text-5xl font-bold text-gray-900 mb-4">Welcome to StyleHub</h1>
        <p className="text-xl text-gray-600 mb-8">Discover quality fashion for every occasion</p>
        <Link 
          to="/products"
          className="inline-block bg-gray-800 text-white px-8 py-3 rounded-lg hover:bg-gray-700 font-medium"
        >
          Shop Now
        </Link>
      </section>
      {/* Featured Products */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-12">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <Link key={product.id} to={`/products/${product.id}`}>
              <div className="border border-gray-300 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 w-full bg-gray-200 overflow-hidden">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-4">
                  <p className="text-xs text-gray-500 uppercase mb-2">{product.category}</p>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-xl font-bold text-gray-900">{product.priceLabel}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    
      <section className="py-16 bg-gray-50 -mx-4 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Why Choose StyleHub?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-3xl mb-3">✓</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Quality Products</h3>
              <p className="text-gray-600">We carefully curate each item for quality and durability</p>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-3">✓</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Fast Shipping</h3>
              <p className="text-gray-600">Quick and reliable delivery to your doorstep</p>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-3">✓</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Great Prices</h3>
              <p className="text-gray-600">Competitive pricing without compromising quality</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Shop?</h2>
        <p className="text-lg text-gray-600 mb-8">Browse our complete collection and find your perfect style</p>
        <Link 
          to="/products"
          className="inline-block bg-gray-800 text-white px-8 py-3 rounded-lg hover:bg-gray-700 font-medium"
        >
          View All Products
        </Link>
      </section>
    </div>
  )
}
