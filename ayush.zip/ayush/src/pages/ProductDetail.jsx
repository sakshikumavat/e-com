import { useParams, Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import products from '../data/products'

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [quantity, setQuantity] = useState(1)

  const productId = Number(id)
  const product = products.find((p) => p.id === productId) || products[0]

  const handleAddToCart = () => {
    alert(`Added ${quantity} ${product.name}(s) to cart!`)
    setQuantity(1)
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <button 
        onClick={() => navigate(-1)}
        className="text-gray-600 hover:text-gray-900 font-medium mb-8"
      >
        ← Back
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Image */}
        <div className="bg-gray-200 h-96 rounded-lg flex items-center justify-center overflow-hidden">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        {/* Product Details */}
        <div>
          <p className="text-sm text-gray-500 uppercase mb-2">{product.category}</p>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>
          <p className="text-3xl font-bold text-gray-900 mb-6">{product.price}</p>

          <p className="text-gray-700 text-lg mb-8 leading-relaxed">
            {product.description}
          </p>

          {/* Size Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Select Size</h3>
            <div className="flex gap-3">
              {['XS', 'S', 'M', 'L', 'XL', 'XXL'].map((size) => (
                <button
                  key={size}
                  className="border-2 border-gray-300 px-4 py-2 rounded hover:border-gray-900 transition-colors"
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Color Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Select Color</h3>
            <div className="flex gap-3">
              {['Black', 'White', 'Navy'].map((color) => (
                <button key={color} className="border-2 border-gray-300 px-4 py-2 rounded hover:border-gray-900 transition-colors">
                  {color}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Quantity</h3>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-100"
              >
                −
              </button>
              <span className="text-lg font-semibold">{quantity}</span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="border border-gray-300 px-4 py-2 rounded hover:bg-gray-100"
              >
                +
              </button>
            </div>
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={handleAddToCart}
            className="w-full bg-gray-800 text-white py-4 rounded-lg hover:bg-gray-700 font-bold text-lg mb-4"
          >
            Add to Cart
          </button>

          {/* Continue Shopping */}
          <Link
            to="/products"
            className="block text-center border-2 border-gray-800 text-gray-800 py-3 rounded-lg hover:bg-gray-50 font-medium"
          >
            Continue Shopping
          </Link>

          {/* Product Info */}
          <div className="mt-12 border-t border-gray-300 pt-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Shipping & Returns</h3>
            <ul className="space-y-2 text-gray-700">
              <li>• Free shipping on orders over $50</li>
              <li>• 30-day return policy</li>
              <li>• 2-3 business days delivery</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
