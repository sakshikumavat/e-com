export default function About() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">About StyleHub</h1>

      
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
        <p className="text-lg text-gray-700 leading-relaxed mb-4">
          At StyleHub, we believe everyone deserves access to quality fashion at reasonable prices. Our mission is to provide curated clothing and accessories that make you feel confident and stylish every day.
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          We handpick each item in our collection to ensure it meets our high standards for quality, durability, and design. Whether you're looking for everyday essentials or statement pieces, we've got you covered.
        </p>
      </section>

      <section className="mb-16 bg-gray-50 -mx-4 px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-4">
            StyleHub started as a small boutique in 2020 with a simple idea: make quality fashion accessible to everyone. What began as a passion project has grown into a thriving online store serving customers worldwide.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            Today, we continue to grow our collection while maintaining the values we started with: authenticity, quality, and customer satisfaction. Every product we sell is chosen with care and backed by our commitment to excellence.
          </p>
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Quality</h3>
            <p className="text-gray-700">We never compromise on quality. Every item is inspected to ensure it meets our standards.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Integrity</h3>
            <p className="text-gray-700">We're transparent about our products, pricing, and practices. Honesty is everything to us.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Customer First</h3>
            <p className="text-gray-700">Your satisfaction is our priority. We're here to help with any questions or concerns.</p>
          </div>
        </div>
      </section>

     
    </div>
  )
}
